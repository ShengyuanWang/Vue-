<template>
  <router-view/>
</template>

<style lang="scss">
*{
  // 设置全局样式(没有设置scpoed)
  margin: 0;
  padding: 0;
}
</style>
