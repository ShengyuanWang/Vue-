# web-admin

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

## 讲解：

- **企业后台管理系统**

## 功能：

1. **登录鉴权（`token + jwt`）**
2. **文件上传(头像上传到服务器)**
3. **用户的增删改查**
4. **新闻的增删改查**
5. **产品的增删改查**
